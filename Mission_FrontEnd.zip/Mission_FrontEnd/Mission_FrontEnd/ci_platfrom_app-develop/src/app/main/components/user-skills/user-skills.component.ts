import { Component, Input, OnDestroy, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgToastService } from 'ng-angular-popup';
import { Subscription } from 'rxjs';
import { CommonService } from '../../services/common.service';
import { APP_CONFIG } from '../../configs/environment.config';

@Component({
  selector: 'app-user-skills',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="user-skills-container">
      <div class="skills-header">
        <h4>My Skills</h4>
        <button 
          type="button" 
          class="btn btn-primary btn-sm" 
          (click)="openAddSkillModal()"
          [disabled]="isLoading">
          <i class="fas fa-plus"></i> Add Skills
        </button>
      </div>

      <!-- Current Skills Display -->
      <div class="current-skills" *ngIf="userSkills.length > 0">
        <h5>Current Skills:</h5>
        <div class="skills-list">
          <span 
            *ngFor="let skill of userSkills" 
            class="skill-tag"
            (click)="removeSkill(skill)">
            {{ skill }}
            <i class="fas fa-times remove-icon"></i>
          </span>
        </div>
      </div>

      <div class="no-skills" *ngIf="userSkills.length === 0 && !isLoading">
        <p>No skills added yet. Click "Add Skills" to get started!</p>
      </div>

      <!-- Loading State -->
      <div class="loading" *ngIf="isLoading">
        <i class="fas fa-spinner fa-spin"></i> Loading skills...
      </div>

      <!-- Add Skills Modal -->
      <div class="modal fade" id="addSkillModal" tabindex="-1" role="dialog" *ngIf="showModal">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Add Your Skills</h5>
              <button type="button" class="btn-close" (click)="closeModal()"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <div class="col-md-6">
                  <h6>Available Skills</h6>
                  <div class="skill-list">
                    <div 
                      *ngFor="let skill of availableSkills" 
                      class="skill-item"
                      (click)="addSkill(skill)"
                      [class.selected]="selectedSkills.includes(skill)">
                      {{ skill }}
                      <i class="fas fa-plus add-icon"></i>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <h6>Selected Skills</h6>
                  <div class="selected-skills">
                    <div 
                      *ngFor="let skill of selectedSkills" 
                      class="selected-skill-item"
                      (click)="removeSelectedSkill(skill)">
                      {{ skill }}
                      <i class="fas fa-minus remove-icon"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" (click)="closeModal()">Cancel</button>
              <button 
                type="button" 
                class="btn btn-primary" 
                (click)="saveSkills()"
                [disabled]="selectedSkills.length === 0 || isSaving">
                <i class="fas fa-spinner fa-spin" *ngIf="isSaving"></i>
                {{ isSaving ? 'Saving...' : 'Save Skills' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .user-skills-container {
      padding: 20px;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      background-color: #f9f9f9;
    }

    .skills-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    .skills-header h4 {
      margin: 0;
      color: #333;
    }

    .current-skills {
      margin-bottom: 20px;
    }

    .skills-list {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 10px;
    }

    .skill-tag {
      background-color: #007bff;
      color: white;
      padding: 5px 12px;
      border-radius: 20px;
      font-size: 14px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      transition: background-color 0.3s;
    }

    .skill-tag:hover {
      background-color: #0056b3;
    }

    .remove-icon {
      font-size: 12px;
      cursor: pointer;
    }

    .no-skills {
      text-align: center;
      color: #666;
      font-style: italic;
    }

    .loading {
      text-align: center;
      color: #666;
    }

    .skill-list, .selected-skills {
      max-height: 300px;
      overflow-y: auto;
      border: 1px solid #ddd;
      border-radius: 4px;
      padding: 10px;
    }

    .skill-item, .selected-skill-item {
      padding: 8px 12px;
      margin: 2px 0;
      border-radius: 4px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: background-color 0.3s;
    }

    .skill-item {
      background-color: #f8f9fa;
      border: 1px solid #e9ecef;
    }

    .skill-item:hover {
      background-color: #e9ecef;
    }

    .skill-item.selected {
      background-color: #d4edda;
      border-color: #c3e6cb;
    }

    .selected-skill-item {
      background-color: #d4edda;
      border: 1px solid #c3e6cb;
    }

    .selected-skill-item:hover {
      background-color: #c3e6cb;
    }

    .add-icon, .remove-icon {
      font-size: 12px;
    }

    .modal {
      display: block;
      background-color: rgba(0, 0, 0, 0.5);
    }
  `]
})
export class UserSkillsComponent implements OnInit, OnDestroy {
  @Input() userId!: number;
  @Output() skillsUpdated = new EventEmitter<string[]>();

  userSkills: string[] = [];
  availableSkills: string[] = [
    'Anthropology', 'Archeology', 'Astronomy', 'Computer Science', 'Environmental Science',
    'History', 'Library Sciences', 'Mathematics', 'Music Theory', 'Research',
    'Administrative Support', 'Customer Service', 'Data Entry', 'Executive Admin',
    'Office Management', 'Office Reception', 'Program Management', 'Transactions',
    'Agronomy', 'Animal Care / Handling', 'Animal Therapy', 'Aquarium Maintenance',
    'Botany', 'Environmental Education', 'Environmental Policy', 'Farming'
  ];
  selectedSkills: string[] = [];
  showModal = false;
  isLoading = false;
  isSaving = false;
  private unsubscribe: Subscription[] = [];

  constructor(private commonService: CommonService, private toast: NgToastService) {}

  ngOnInit(): void {
    if (this.userId) {
      this.loadUserSkills();
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe.forEach(sub => sub.unsubscribe());
  }

  loadUserSkills(): void {
    this.isLoading = true;
    const subscription = this.commonService.getUserSkill(this.userId).subscribe({
      next: (response: any) => {
        this.isLoading = false;
        if (response.result === 1) {
          if (response.data && response.data.length > 0) {
            // Handle different response formats
            if (typeof response.data[0] === 'object' && response.data[0].text) {
              this.userSkills = response.data[0].text.split(',').map((skill: string) => skill.trim());
            } else if (Array.isArray(response.data)) {
              this.userSkills = response.data.map((skill: any) => 
                typeof skill === 'string' ? skill.trim() : skill.text || skill
              );
            }
          } else {
            this.userSkills = [];
          }
        } else {
          this.toast.error({
            detail: 'ERROR',
            summary: response.message || 'Failed to load skills',
            duration: APP_CONFIG.toastDuration
          });
        }
      },
      error: (error) => {
        this.isLoading = false;
        this.toast.error({
          detail: 'ERROR',
          summary: error.message || 'Failed to load skills',
          duration: APP_CONFIG.toastDuration
        });
      }
    });
    this.unsubscribe.push(subscription);
  }

  openAddSkillModal(): void {
    this.selectedSkills = [...this.userSkills];
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
    this.selectedSkills = [];
  }

  addSkill(skill: string): void {
    if (!this.selectedSkills.includes(skill)) {
      this.selectedSkills.push(skill);
    }
  }

  removeSelectedSkill(skill: string): void {
    this.selectedSkills = this.selectedSkills.filter(s => s !== skill);
  }

  removeSkill(skill: string): void {
    this.userSkills = this.userSkills.filter(s => s !== skill);
    this.saveSkills();
  }

  saveSkills(): void {
    if (this.selectedSkills.length === 0) {
      this.toast.warning({
        detail: 'WARNING',
        summary: 'Please select at least one skill',
        duration: APP_CONFIG.toastDuration
      });
      return;
    }

    this.isSaving = true;
    const skillData = {
      skill: this.selectedSkills.join(','),
      userId: this.userId
    };

    const subscription = this.commonService.addUserSkill(skillData).subscribe({
      next: (response: any) => {
        this.isSaving = false;
        if (response.result === 1) {
          this.userSkills = [...this.selectedSkills];
          this.skillsUpdated.emit(this.userSkills);
          this.toast.success({
            detail: 'SUCCESS',
            summary: response.data || 'Skills updated successfully',
            duration: APP_CONFIG.toastDuration
          });
          this.closeModal();
        } else {
          this.toast.error({
            detail: 'ERROR',
            summary: response.message || 'Failed to save skills',
            duration: APP_CONFIG.toastDuration
          });
        }
      },
      error: (error) => {
        this.isSaving = false;
        this.toast.error({
          detail: 'ERROR',
          summary: error.message || 'Failed to save skills',
          duration: APP_CONFIG.toastDuration
        });
      }
    });
    this.unsubscribe.push(subscription);
  }
} 