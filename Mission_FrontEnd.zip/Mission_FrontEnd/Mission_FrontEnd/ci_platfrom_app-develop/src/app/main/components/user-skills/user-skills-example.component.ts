import { Component } from '@angular/core';
import { UserSkillsComponent } from './user-skills.component';

@Component({
  selector: 'app-user-skills-example',
  standalone: true,
  imports: [UserSkillsComponent],
  template: `
    <div class="container">
      <h2>User Skills Management Example</h2>
      <app-user-skills 
        [userId]="currentUserId" 
        (skillsUpdated)="onSkillsUpdated($event)">
      </app-user-skills>
    </div>
  `,
  styles: [`
    .container {
      padding: 20px;
      max-width: 800px;
      margin: 0 auto;
    }
  `]
})
export class UserSkillsExampleComponent {
  currentUserId = 1; // Replace with actual user ID

  onSkillsUpdated(skills: string[]): void {
    console.log('Skills updated:', skills);
    // Handle skills update - maybe update form or trigger other actions
  }
} 